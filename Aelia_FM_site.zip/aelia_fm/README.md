# AELIA FM — a cultura não silencia

Site interativo de presente para Aelia, com estética em tons de verde, música, literatura, humor e uma mensagem pessoal.

## Arquivos
- `index.html` — estrutura e conteúdo.
- `style.css` — visual responsivo, cores, layout e animações.
- `script.js` — navegação, estações, notas literárias e minijogos.

## Como abrir
Abra `index.html` em um navegador. Para publicar, envie os três arquivos para um repositório do GitHub e ative GitHub Pages, ou arraste a pasta/ZIP para um serviço de hospedagem estática como Netlify.

## Personalizar antes de enviar
- Confira a mensagem em `index.html`, na seção `id="note"`, para deixar o texto exatamente com a sua voz.
- O botão “Ouvir nossa Jam” já abre a playlist enviada: `https://open.spotify.com/playlist/5lEkR5HoInNCc1m2wOKT0u`.
- A recomendação de blues aparece como **Ray Charles & Lionel Richie**. O link de áudio abre uma busca no YouTube para não presumir uma gravação específica.
- Fontes são carregadas do Google Fonts; sem internet, o site usa fontes alternativas locais.

## Observações
Não há login, banco de dados nem áudio automático. O site é estático e funciona em celular e computador.
